﻿namespace Kinect_Middleware.Kinect {
    /// <summary>
    /// Enum indicating the selected kinect device
    /// </summary>
    public enum KinectType {
        None,
        Azure,
        One
    }
}
