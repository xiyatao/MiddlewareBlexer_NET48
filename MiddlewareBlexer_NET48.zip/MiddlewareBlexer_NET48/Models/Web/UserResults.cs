﻿namespace Kinect_Middleware.Models {

    public class UserResults {
        public int id_user;
        public ExerciseResult[] resultsArray;
    }
}
