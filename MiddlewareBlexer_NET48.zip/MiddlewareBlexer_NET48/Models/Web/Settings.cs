﻿namespace Kinect_Middleware.Models {
    public class Setting {
        public int id_setting;

        public string param1;
        public string param2;
        public string param3;
        public string param4;
    }
}
