﻿namespace Kinect_Middleware.Models {
    public class Game {
        public string gameInfo;
        public Exercise[] exercises;
    }
}
